
Readme gives a list of projects created using shakti.


