Please refer 

*  [`License`](https://gitlab.com/shaktiproject/software/shakti-sdk-dev/blob/master/License) for a detail description on License.

*  [`doc/howto_develop.md`](https://gitlab.com/shaktiproject/software/shakti-sdk-dev/blob/master/doc/howto_develop.md) for a detail description on application development.