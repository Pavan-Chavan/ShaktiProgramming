Setting up the LED test:

1. Connect one end of the led to the selected pwm module output on the board and the other end to ground.
2. Load the pwmled.shakti to the board and run

