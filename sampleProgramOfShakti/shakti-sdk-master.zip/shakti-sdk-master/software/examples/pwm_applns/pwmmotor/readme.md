Setting up the Motor test:

1. Connect one end of the motor to the selected pwm module output on the board and the other end to ground.
2. The motor might require a lot more input power so connect the board to external power supply.
3. Load the pwmmotor.shakti to the board and run

