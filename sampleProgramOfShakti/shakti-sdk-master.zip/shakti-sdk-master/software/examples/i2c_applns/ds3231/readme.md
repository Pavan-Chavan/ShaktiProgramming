sensor - lm75
peripheral - i2c

<readme to follow>